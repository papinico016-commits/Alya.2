package com.mochi.pet

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.SystemClock
import android.view.View
import kotlin.math.abs
import kotlin.math.sin

class PetView(ctx: Context) : View(ctx) {
    var emotion = "neutral"
    var walking = false
    var speaking = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var nextBlink = 0L
    private val hair = 0xFF7B5FD6.toInt()
    private val skin = 0xFFFBE4D6.toInt()
    private val jacket = 0xFF2F3C7E.toInt()
    private val skirt = 0xFFC2415F.toInt()
    private val ink = 0xFF3B2A66.toInt()

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val now = SystemClock.uptimeMillis()
        val t = (now % 100000L) / 1000f
        val sleeping = emotion == "dormida"
        if (now > nextBlink + 160) nextBlink = now + 2500 + (now % 2300)
        val blinking = sleeping || (now >= nextBlink && now < nextBlink + 150)
        val sw = if (walking) sin(t * 10f) else sin(t * 2f) * 0.12f
        val bob = if (walking) abs(sin(t * 10f)) * -5f else sin(t * 2f) * 2f + (if (emotion == "tristeza") 6f else 0f)

        var aL = 8f + sw * 20f
        var aR = 8f - sw * 20f
        if (walking) { aL = sw * 35f; aR = -sw * 35f }
        when (emotion) {
            "feliz" -> { aR = 150f + sin(t * 12f) * 20f; aL = 10f }
            "sorpresa" -> { aL = 140f; aR = 140f }
            "enojo" -> { aL = 15f + sin(t * 30f) * 4f; aR = 15f - sin(t * 30f) * 4f }
            "tristeza", "dormida" -> { aL = 4f; aR = 4f }
            "pensando" -> { aR = 100f }
            "duda" -> { aL = 25f + sin(t * 3f) * 10f }
        }

        c.save()
        c.scale(width / 200f, width / 200f)
        c.translate(0f, bob)
        p.style = Paint.Style.FILL
        p.color = hair
        val tw = sin(t * 3f) * 3f + (if (walking) sw * 6f else 0f)
        c.drawCircle(46f + tw, 118f, 18f, p)
        c.drawCircle(154f - tw, 118f, 18f, p)
        c.drawOval(RectF(40f, 36f, 160f, 160f), p)
        leg(c, 88f, 215f, sw * 28f)
        leg(c, 112f, 215f, -sw * 28f)
        p.style = Paint.Style.FILL
        p.color = jacket
        c.drawRoundRect(RectF(72f, 150f, 128f, 222f), 14f, 14f, p)
        p.color = skirt
        path.reset()
        path.moveTo(66f, 200f); path.lineTo(134f, 200f); path.lineTo(146f, 226f); path.lineTo(54f, 226f); path.close()
        c.drawPath(path, p)
        arm(c, 72f, 160f, aL)
        arm(c, 128f, 160f, -aR)
        p.style = Paint.Style.FILL
        p.color = skin
        c.drawCircle(100f, 105f, 50f, p)
        face(c, t, blinking)
        p.style = Paint.Style.FILL
        p.color = hair
        path.reset()
        path.moveTo(50f, 100f); path.quadTo(48f, 50f, 100f, 50f); path.quadTo(152f, 50f, 150f, 100f)
        path.quadTo(140f, 74f, 118f, 82f); path.quadTo(100f, 70f, 82f, 82f); path.quadTo(60f, 74f, 50f, 100f); path.close()
        c.drawPath(path, p)
        c.restore()
        postInvalidateDelayed(40)
    }

    private fun leg(c: Canvas, x: Float, y: Float, deg: Float) {
        c.save(); c.rotate(deg, x, y)
        p.style = Paint.Style.FILL
        p.color = skin; c.drawRoundRect(RectF(x - 7f, y, x + 7f, y + 58f), 7f, 7f, p)
        p.color = ink; c.drawRoundRect(RectF(x - 10f, y + 52f, x + 12f, y + 66f), 6f, 6f, p)
        c.restore()
    }

    private fun arm(c: Canvas, x: Float, y: Float, deg: Float) {
        c.save(); c.rotate(deg, x, y)
        p.style = Paint.Style.FILL
        p.color = jacket; c.drawRoundRect(RectF(x - 6f, y - 4f, x + 6f, y + 26f), 6f, 6f, p)
        p.color = skin; c.drawRoundRect(RectF(x - 5f, y + 22f, x + 5f, y + 46f), 5f, 5f, p)
        c.drawCircle(x, y + 48f, 7f, p)
        c.restore()
    }

    private fun face(c: Canvas, t: Float, blinking: Boolean) {
        var ry = 11f; var ryL = 11f; var bl = 0f; var br = 0f; var blush = 70
        when (emotion) {
            "feliz" -> { ry = 8f; ryL = 8f; bl = -4f; br = 4f; blush = 230 }
            "duda" -> { ryL = 7f; bl = -16f; br = 8f; blush = 40 }
            "enojo" -> { ry = 8f; ryL = 8f; bl = 24f; br = -24f; blush = 120 }
            "tristeza" -> { bl = -20f; br = 20f; blush = 30 }
            "sorpresa" -> { ry = 15f; ryL = 15f }
            "pensando" -> { bl = -6f; br = 6f }
        }
        if (blinking) { ry = 1.5f; ryL = 1.5f }
        p.style = Paint.Style.FILL
        p.color = Color.argb(blush, 255, 123, 150)
        c.drawOval(RectF(53f, 119f, 71f, 129f), p)
        c.drawOval(RectF(129f, 119f, 147f, 129f), p)
        val dx = if (emotion == "pensando") 4f else 0f
        val dy = if (emotion == "pensando") -4f else 0f
        p.color = ink
        c.drawOval(RectF(65f + dx, 108f + dy - ryL, 87f + dx, 108f + dy + ryL), p)
        c.drawOval(RectF(113f + dx, 108f + dy - ry, 135f + dx, 108f + dy + ry), p)
        if (!blinking) {
            p.color = Color.WHITE
            c.drawCircle(72f + dx, 104f + dy, 3f, p)
            c.drawCircle(120f + dx, 104f + dy, 3f, p)
        }
        p.style = Paint.Style.STROKE
        p.strokeWidth = 4f
        p.strokeCap = Paint.Cap.ROUND
        p.color = ink
        c.save(); c.rotate(bl, 76f, 86f); c.drawLine(62f, 86f, 90f, 86f, p); c.restore()
        c.save(); c.rotate(br, 124f, 86f); c.drawLine(110f, 86f, 138f, 86f, p); c.restore()
        p.strokeWidth = 3.5f
        p.color = 0xFF7A2E45.toInt()
        if (speaking) {
            p.style = Paint.Style.FILL
            val o = 3f + 6f * abs(sin(t * 14f))
            c.drawOval(RectF(91f, 131f - o, 109f, 131f + o), p)
        } else {
            path.reset()
            when (emotion) {
                "feliz" -> { path.moveTo(82f, 123f); path.quadTo(100f, 145f, 118f, 123f) }
                "duda" -> { path.moveTo(90f, 132f); path.quadTo(100f, 125f, 112f, 133f) }
                "enojo" -> { path.moveTo(86f, 135f); path.quadTo(100f, 123f, 114f, 135f) }
                "tristeza" -> { path.moveTo(88f, 136f); path.quadTo(100f, 125f, 112f, 136f) }
                "sorpresa" -> { p.style = Paint.Style.FILL; path.addOval(RectF(93f, 124f, 107f, 144f), Path.Direction.CW) }
                "pensando" -> { path.moveTo(92f, 130f); path.lineTo(108f, 130f) }
                "dormida" -> { path.moveTo(92f, 129f); path.quadTo(100f, 133f, 108f, 129f) }
                else -> { path.moveTo(88f, 128f); path.quadTo(100f, 134f, 112f, 128f) }
            }
            c.drawPath(path, p)
        }
        if (emotion == "tristeza") {
            p.style = Paint.Style.FILL
            p.color = 0xFF7CC4FF.toInt()
            val d = (t * 20f) % 14f
            c.drawOval(RectF(60f, 124f + d, 68f, 134f + d), p)
        }
        p.style = Paint.Style.FILL
    }
}
