package com.mochi.pet

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Api {
    private fun post(url: String, headers: Map<String, String>, body: String): Pair<String?, String> {
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 40000; c.doOutput = true
            c.setRequestProperty("content-type", "application/json")
            for ((k, v) in headers) c.setRequestProperty(k, v)
            c.outputStream.use { it.write(body.toByteArray()) }
            val code = c.responseCode
            if (code in 200..299) Pair(c.inputStream.bufferedReader().readText(), "")
            else Pair(null, when (code) {
                400, 401, 403 -> "La clave no sirve o no tiene permiso ($code)."
                404 -> "404"
                429 -> "Ya usaste toda la cuota por ahora ($code). Espera un poco."
                else -> "Error de la IA ($code)."
            })
        } catch (e: Exception) {
            Pair(null, "No hay internet o no pude conectarme.")
        }
    }

    fun ask(key: String, prompt: String): Pair<String?, String> {
        return try {
            if (key.startsWith("sk-ant")) {
                val body = JSONObject().put("model", "claude-haiku-5-5").put("max_tokens", 300)
                    .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt))).toString()
                val r = post("https://api.anthropic.com/v1/messages", mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), body)
                if (r.first == null) return Pair(null, r.second)
                Pair(JSONObject(r.first!!).getJSONArray("content").getJSONObject(0).getString("text"), "")
            } else {
                val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt))))).toString()
                var err = ""
                for (m in listOf("gemini-2.5-flash", "gemini-3-flash-preview")) {
                    val r = post("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent", mapOf("x-goog-api-key" to key), body)
                    if (r.first != null) {
                        val text = JSONObject(r.first!!).getJSONArray("candidates").getJSONObject(0)
                            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                        return Pair(text, "")
                    }
                    err = r.second
                    if (err != "404") break
                }
                Pair(null, if (err == "404") "No encontré el modelo de IA (404)." else err)
            }
        } catch (e: Exception) {
            Pair(null, "La IA respondió algo raro.")
        }
    }
}
